import java.util.ArrayList;

public class Paths {
	
	public Paths(int cx, int cy)
	{
		int x = cx;
		int y = cy; 
	}
}
	

